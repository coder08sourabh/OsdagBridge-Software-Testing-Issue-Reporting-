"""truss designer (stub)."""
