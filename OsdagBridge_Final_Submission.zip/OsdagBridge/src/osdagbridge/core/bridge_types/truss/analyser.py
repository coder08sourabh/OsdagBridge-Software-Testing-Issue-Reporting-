"""truss analyser (stub)."""
