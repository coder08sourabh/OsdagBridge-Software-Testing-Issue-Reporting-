"""Pile cap geometry stub."""
