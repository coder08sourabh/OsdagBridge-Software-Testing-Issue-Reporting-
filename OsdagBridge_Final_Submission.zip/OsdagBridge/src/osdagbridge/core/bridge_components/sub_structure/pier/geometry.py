"""Pier geometry stub."""
