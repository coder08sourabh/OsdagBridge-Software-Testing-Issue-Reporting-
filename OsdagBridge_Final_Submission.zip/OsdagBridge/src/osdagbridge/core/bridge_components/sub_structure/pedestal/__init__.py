"""Pedestal package."""
