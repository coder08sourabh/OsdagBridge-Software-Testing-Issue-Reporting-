"""Pedestal geometry stub."""
