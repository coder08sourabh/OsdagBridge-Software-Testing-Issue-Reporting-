"""bridge_components package."""
